#include "PeaBullet.h"

PeaBullet::PeaBullet(Point p_pos)
	:Bullet(p_pos, BULLET_SIZE, IMAGEPATH_PEA_BULLET)
{
}
