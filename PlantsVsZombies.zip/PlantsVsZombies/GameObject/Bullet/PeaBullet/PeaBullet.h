#pragma once
#include "../Bullet.h"

class PeaBullet : public Bullet
{
public:
	PeaBullet(Point p_pos);
};