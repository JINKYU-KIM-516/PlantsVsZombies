#include "IcePeaBullet.h"

IcePeaBullet::IcePeaBullet(Point p_pos)
	:Bullet(p_pos, BULLET_SIZE, IMAGEPATH_ICEPEA_BULLET)
{

}
