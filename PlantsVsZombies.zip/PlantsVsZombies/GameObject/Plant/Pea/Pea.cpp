#include "Pea.h"

//protected
void Pea::SpawnBullet()
{
	PeaBullet* bullet = new PeaBullet(m_positon + Point(PLANT_WIDTH / 2 + BULLET_WIDTH, PLANT_HEIGHT / 2 - BULLET_HEIGHT));
	bullet->Init(m_attackPower, MOVESPEED_BULLET_PEA);

	m_bulletManager->AddBullets(bullet);
}

void Pea::SpawnBulletPeriodically()
{
	if (m_attackTimer.HasElapsed())
	{
		SpawnBullet();
		m_attackTimer.Tick();
	}
}


//public
Pea::Pea()
	:Plant(DEFAULT_POSITION, PLANT_SIZE, IMAGEPATH_PEA)
{
	m_bulletManager = nullptr;
	m_hp = 150;
	m_attackPower = ATTACKPOWER_PEA;
	m_attackSpeed = ATTACKSPEED_PEA;
	m_attackTimer.Init(m_attackSpeed);
}

Pea::~Pea()
{
}

void Pea::Init(Point p_pos, BulletManager* p_bulletManager)
{
	m_positon = p_pos;
	m_bulletManager = p_bulletManager;
}

void Pea::Update()
{
	SpawnBulletPeriodically();
	CheckAlive();
}