#pragma once
#include <windows.h>
#include <vector>
#include "Player.h"
class MainGame
{
private:
	Player* m_player;
	HWND m_hWnd;
public:
	MainGame(HWND);
	void DrawAll(HDC hdc);
};