#include "MainGame.h"

MainGame::MainGame(HWND p_hWnd)
{
	m_hWnd = p_hWnd;
	m_player = new Player();
	m_player->SpawnSunflower();
	InvalidateRect(m_hWnd, NULL, TRUE);  // �� ȣ��!
}

void MainGame::DrawAll(HDC hdc)
{
	for (auto* sunflower : m_player->GetSunflowers())
		sunflower->Draw(hdc);
}
