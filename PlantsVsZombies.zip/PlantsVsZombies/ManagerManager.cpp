#include "ManagerManager.h"
#include "MainGame.h"

ManagerManager::ManagerManager(MainGame* p_mainGame)
{
	m_mainGame = p_mainGame;
	Init();
}

ManagerManager::~ManagerManager()
{
	for (auto* manager : m_managers)
	{
		delete manager;
	}
}

void ManagerManager::Init()
{
	GameBoard* gameBoard = new GameBoard();
	PlantManager* plantManager = new PlantManager();
	SunlightManager* sunlightManager = new SunlightManager();
	BulletManager* bulletManager = new BulletManager();
	ZombieManager* zombieManager = new ZombieManager();
	CollisionManager* collisionManager = new CollisionManager();
	Store* store = new Store();
	Player* player = new Player();

	AddManager(gameBoard);
	AddManager(plantManager);
	AddManager(sunlightManager);
	AddManager(bulletManager);
	AddManager(zombieManager);
	AddManager(collisionManager);
	AddManager(store);
	AddManager(player);

	Link(m_mainGame);
}

void ManagerManager::Link(MainGame* p_mainGame)
{
	dynamic_cast<GameBoard*>(m_managers[GAMEBOARD_INDEX])->Link(m_mainGame);

	dynamic_cast<PlantManager*>(m_managers[PLANT_MANAGER_INDEX])->Link(
		dynamic_cast<SunlightManager*>(m_managers[SUNLIGHT_MANAGER_INDEX]),
		dynamic_cast<BulletManager*>(m_managers[BULLET_MANAGER_INDEX])
	);

	dynamic_cast<SunlightManager*>(m_managers[SUNLIGHT_MANAGER_INDEX])->Link(m_mainGame);

	dynamic_cast<CollisionManager*>(m_managers[COLLISION_MANAGER_INDEX])->Link(
		dynamic_cast<PlantManager*>(m_managers[PLANT_MANAGER_INDEX]),
		dynamic_cast<ZombieManager*>(m_managers[ZOMBIE_MANAGER_INDEX]),
		dynamic_cast<BulletManager*>(m_managers[BULLET_MANAGER_INDEX])
	);

	dynamic_cast<Store*>(m_managers[STORE_INDEX])->Link(m_mainGame);
	dynamic_cast<Player*>(m_managers[PLAYER_INDEX])->Link(m_mainGame);
}

void ManagerManager::Update()
{
	for (auto* manager : m_managers)
	{
		manager->Update();
	}
}

void ManagerManager::ClickHandle()
{
	for (auto* manager : m_managers)
	{
		manager->ClickHandle();
	}
}

void ManagerManager::Draw(HDC p_hdc)
{
	for (auto* manager : m_managers)
	{
		manager->Draw(p_hdc);
	}
}

void ManagerManager::AddManager(BaseManager* p_manager)
{
	m_managers.push_back(p_manager);
}

const vector<BaseManager*>& ManagerManager::GetManagers() const
{
	return m_managers;
}
