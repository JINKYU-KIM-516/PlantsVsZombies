#pragma once
#include <list>
#include <algorithm>
#include "Bullet.h"

using namespace std;

class BulletManager
{
protected:
	list<Bullet*> m_bullets;
public:
    ~BulletManager();
    void Update();

    void AddBullets(Bullet* p_bullet);
    void DeleteBullets();
    const list<Bullet*>& GetBullets() const;
};