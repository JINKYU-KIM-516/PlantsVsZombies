#include "Player.h"

Player::Player()
{
	m_sunlight = 0;
	m_state = PlayerState::Normal;
	m_selectedCode = -1;
}

void Player::Init()
{

}

int Player::GetSunlight()
{
	return m_sunlight;
}

void Player::SetSunlight(int p_sunlight)
{
	m_sunlight = p_sunlight;
}

void Player::SetState(int p_state)
{
	m_state = p_state;
}

void Player::SetSelectedCode(int p_code)
{
	m_selectedCode = p_code;
}