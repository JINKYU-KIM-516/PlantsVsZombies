#include "Player.h"

Player::Player()
{
	m_sunlight = 0;
}

void Player::Init()
{

}