#include "BulletPea.h"

BulletPea::BulletPea(Point p_pos)
	:Bullet(p_pos, BULLET_SIZE, IMAGEPATH_BULLET_PEA)
{
}
