#include "Sunflower.h"

Sunflower::Sunflower()
{
	m_hp = 100;
	m_size = Size(PLANTSIZE, PLANTSIZE);
}

void Sunflower::Init(Point p_pos)
{
	m_location = p_pos;
}

void Sunflower::Draw(HDC hdc)
{
    Rectangle(hdc,
        m_location.GetX(),
        m_location.GetY(),
        m_location.GetX() + m_size.GetWidth(),
        m_location.GetY() + m_size.GetHeight());
}