#pragma once
#include "Bullet.h"

class BulletPea : public Bullet
{
public:
	BulletPea(Point p_pos);
};