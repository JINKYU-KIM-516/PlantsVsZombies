#pragma once
#include <windows.h>

#include "Constants.h"
#include "Point.h"
#include "Size.h"

class Sunflower
{
private:
	int m_hp;
	Point m_location;
	Size m_size;
public:
	Sunflower();
	
	void Init(Point p_pos);
	void Draw(HDC hdc);
};