#pragma once
#include "PictureBox.h"
#include "Constants.h"

class Tile : public PictureBox
{
public:
	Tile(Point p_pos, wstring p_imagePath);
};

