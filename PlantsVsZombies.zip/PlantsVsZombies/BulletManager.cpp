#include "BulletManager.h"

BulletManager::~BulletManager()
{
	for (auto* b : m_bullets)
		delete b;
}

void BulletManager::Update()
{
	DeleteBullets();
}

void BulletManager::AddBullets(Bullet* p_bullet)
{
	m_bullets.push_back(p_bullet);
}

void BulletManager::DeleteBullets()
{
	for (auto bullet = m_bullets.begin(); bullet != m_bullets.end(); )
	{
		if ((*bullet)->GetLocation().GetX() > (GAMEBOAORD_WIDTH + 1) * TILE_WIDTH)
		{
			delete* bullet;
			bullet = m_bullets.erase(bullet);  // ���� �� ���� ��ҷ�
		}
		else
		{
			++bullet;
		}
	}
}

const list<Bullet*>& BulletManager::GetBullets() const
{
	return m_bullets;
}
