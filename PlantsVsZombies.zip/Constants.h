#define TILE_SIZE 64
#define PLANT_SIZE 64
#define ZOMBIE_SIZE 64

#define IMAGEPATH_FIELD_GRASS L"../Resources_PlantsVsZombies_bmp/field_grass.bmp"

#define IMAGEPATH_SUNFLOWER L"../Resources_PlantsVsZombies_bmp/plant_sunflower.bmp"
#define IMAGEPATH_PEA L"../Resources_PlantsVsZombies_bmp/plant_pea.bmp"

#define IMAGEPATH_ZOMBIE L"../Resources_PlantsVsZombies_bmp/zombie.bmp"